// Example controller file
module.exports = {
    exampleFunction: (req, res) => {
        res.send("This is an example function.");
    },
};
